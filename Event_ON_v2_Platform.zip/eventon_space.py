"""Shared spatial model; deterministic heuristic planning, not a trained AI model."""
import json, math, random
from collections import deque
from pathlib import Path
from geometry import geometry, inside, fits, COLORS, SIZES

STRATEGIES={
 '동선 균형형': {'spread':1.,'medical':1.,'travel':1.5,'target':1.},
 '응급 접근형': {'spread':.6,'medical':4.,'travel':1.,'target':.7},
 '혼잡 분산형': {'spread':3.5,'medical':1.,'travel':.6,'target':.5},
}

def demand(data):
    weights={}
    event=data.get('event_type','축제');age=data.get('age','전 연령');mood=data.get('mood','활기찬')
    for name in data.get('facilities',[]):
        value={'공연장':1.8,'푸드존':1.4,'체험 부스':1.5,'휴게 공간':.7,'안내센터':.3,'응급의료센터':.04,'화장실':.5,'굿즈 판매':.6}.get(name,1.)
        if event=='공연' and name=='공연장':value*=1.8
        if event in ('체험 행사','박람회') and name=='체험 부스':value*=1.7
        if age in ('어린이·가족','청소년') and name=='체험 부스':value*=1.4
        if age=='고령층' and name=='휴게 공간':value*=1.7
        if mood=='차분한' and name=='휴게 공간':value*=1.3
        if mood=='활기찬' and name=='공연장':value*=1.2
        if float(data.get('hours',8))>=6 and name=='푸드존':value*=1.2
        weights[name]=value
    total=sum(weights.values()) or 1
    return {n:v/total for n,v in weights.items()}

def spatial_grid(p):
    w,h=math.ceil(p['width']),math.ceil(p['depth']);free=bytearray(w*h)
    for y in range(h):
        for x in range(w):
            px,py=x+.5,y+.5
            free[y*w+x]=inside(px,py,p['polygon']) and not any(abs(px-z['x'])<z['w']/2+.7 and abs(py-z['y'])<z['h']/2+.7 for z in p['zones'])
    def nearest(x,y):
        return min((i for i,f in enumerate(free) if f),key=lambda i:(i%w+.5-x)**2+(i//w+.5-y)**2,default=-1)
    return w,h,free,nearest

def bfs(start,w,h,free):
    prev=[-1]*len(free);dist=[-1]*len(free)
    if start<0:return prev,dist
    prev[start]=start;dist[start]=0;q=deque([start])
    while q:
        i=q.popleft();x,y=i%w,i//w
        for nx,ny in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
            if 0<=nx<w and 0<=ny<h:
                k=ny*w+nx
                if free[k] and prev[k]<0:prev[k]=i;dist[k]=dist[i]+1;q.append(k)
    return prev,dist

def analyze(p,data):
    w,h,free,nearest=spatial_grid(p);gate=p['gates'][0];start=nearest(gate['x'],gate['y']);prev,dist=bfs(start,w,h,free)
    route_usage={};routes=[];connected=0;distance=0;shares=demand(data);nodes={}
    for z in p['zones']:
        n=nearest(z['x'],z['y']-z['h']/2-1.5);nodes[z['name']]=n
        reachable=n>=0 and dist[n]>=0;z['reachable']=reachable;z['share']=shares.get(z['name'],0)
        z['route_distance']=dist[n] if reachable else None
        if not reachable:continue
        connected+=1;distance+=dist[n]*z['share'];path=[];k=n
        while k!=start:
            path.append([k%w+.5,k//w+.5]);route_usage[k]=route_usage.get(k,0)+z['share'];k=prev[k]
        path.append([start%w+.5,start//w+.5]);routes.append({'name':z['name'],'points':path[::-1]})
    medical=nodes.get('응급의료센터',-1);medical_distance=None
    if medical>=0:
        _,md=bfs(medical,w,h,free);vals=[md[n] for n in nodes.values() if n>=0 and n!=medical and md[n]>=0]
        if vals: medical_distance=round(sum(vals)/len(vals),1)
        medical_route=next((r['points'] for r in routes if r['name']=='응급의료센터'),[])
    else:medical_route=[]
    busy=[z for z in p['zones'] if z['name'] in ('공연장','푸드존','체험 부스','굿즈 판매')]
    separations=[math.dist((a['x'],a['y']),(b['x'],b['y'])) for i,a in enumerate(busy) for b in busy[i+1:]]
    area=sum(inside(x+.5,y+.5,p['polygon']) for y in range(h) for x in range(w));facility_area=sum(z['w']*z['h'] for z in p['zones'])
    p['routes']=routes;p['medical_route']=medical_route
    p['metrics']={'connected':connected,'facilities':len(p['zones']),'weighted_distance':round(distance/max(.001,sum(z['share'] for z in p['zones'] if z['reachable'])),1),'medical_distance':medical_distance,'busy_separation':round(sum(separations)/len(separations),1) if separations else 0,'facility_area_pct':round(100*facility_area/max(1,area),1),'shared_route_pct':round(100*sum(v>.6 for v in route_usage.values())/max(1,len(route_usage)),1),'free_area':int(sum(free))}
    # Route overlap is a geometric demand proxy, not a physical crowd density prediction.
    return p

def plan(data,analyze_routes=True):
    w,h,poly,gates=geometry(data);placed=[];warnings=[];shares=demand(data)
    strategy=data.get('strategy','동선 균형형');weights=STRATEGIES.get(strategy,STRATEGIES['동선 균형형'])
    anchors={'공연장':(.5,.8),'푸드존':(.8,.65),'체험 부스':(.23,.55),'휴게 공간':(.75,.3),'응급의료센터':(.22,.25),'안내센터':(.3,.15),'화장실':(.15,.72),'굿즈 판매':(.72,.8)}
    saved=data.get('layout_positions',{}) or {};clearance=float(data.get('clearance',1.5));scale=max(.85,min(1.6,math.sqrt(max(100,int(data.get('visitors',1200)))/1200)))
    # Deliberately reserve central walking space; actual paths are subsequently solved on the free-space grid.
    spine={'x':w*.46,'y':h*.48,'w':float(data.get('corridor_width',3)),'h':h*.72}
    cross={'x':w*.5,'y':h*.48,'w':w*.72,'h':float(data.get('corridor_width',3))}
    reserved=[spine,cross]
    facilities=list(dict.fromkeys(data.get('facilities',list(COLORS)[:6])))
    facilities.sort(key=lambda n:(n not in ('공연장','응급의료센터','안내센터'),-shares.get(n,0)))
    for name in facilities:
        bw,bh=SIZES.get(name,(7,5));bw=round(bw*scale,1);bh=round(bh*scale,1)
        ax,ay=anchors.get(name,(.5,.5));requested=saved.get(name)
        if requested:ax,ay=map(float,requested)
        def valid(pt):return fits(pt[0],pt[1],bw,bh,poly,placed+reserved,clearance)
        candidates=[(ix,iy) for ix in range(2,int(w),3) for iy in range(2,int(h),3) if valid((ix,iy))]
        target=(round(ax*w,8),round(ay*h,8))
        def cost(pt):
            x,y=pt;v=weights['target']*math.dist(pt,target)/max(w,h)
            v+=weights['travel']*math.dist(pt,(gates[0]['x'],gates[0]['y']))*shares.get(name,0)/max(w,h)
            if name=='응급의료센터':v+=weights['medical']*(abs(x-spine['x'])+math.dist(pt,(gates[0]['x'],gates[0]['y'])))/max(w,h)
            if name in ('공연장','푸드존','체험 부스','굿즈 판매'):
                for z in placed:
                    if z['name'] in ('공연장','푸드존','체험 부스','굿즈 판매'):v+=weights['spread']*max(0,.45-math.dist(pt,(z['x'],z['y']))/max(w,h))
            if name=='안내센터':v+=2*math.dist(pt,(gates[0]['x'],gates[0]['y']))/max(w,h)
            return v
        if requested and valid(target):x,y=target
        elif candidates:
            x,y=min(candidates,key=cost)
            if requested:warnings.append(name+'의 좌표를 외곽·시설 간격·주 통로 조건에 맞게 보정했습니다.')
        else:
            warnings.append(name+'의 배치 공간이 부족합니다. 크기를 늘리거나 시설 수를 줄이세요.');continue
        placed.append({'name':name,'x':x,'y':y,'w':bw,'h':bh,'color':COLORS.get(name,'#64748b'),'share':shares.get(name,0)})
    p={'width':w,'depth':h,'polygon':poly,'gates':gates,'zones':placed,'warnings':warnings,'shape':data.get('venue_shape','직사각형 (기본)'),'name':data.get('name','새 행사'),'visitors':int(data.get('visitors',1200)),'strategy':strategy,'reserved':reserved,'seed':int(data.get('seed',42)),'peak_fraction':float(data.get('peak_fraction',.25))}
    if analyze_routes:
        analyze(p,data)
        for z in p['zones']:
            if not z['reachable']:p['warnings'].append(z['name']+'의 접근 경로가 연결되지 않습니다. 배치를 수정하세요.')
    return p

def actual_data(data,p=None):
    p=p or plan(data);out=dict(data);out['layout_positions']={z['name']:(z['x']/p['width'],z['y']/p['depth']) for z in p['zones']};return out

def optimize_layout_candidates(data):
    result=[]
    for name in STRATEGIES:
        d=dict(data);d['strategy']=name;d['layout_positions']={};p=plan(d)
        result.append({'name':name,'positions':actual_data(d,p)['layout_positions'],'metrics':p['metrics'],'warnings':p['warnings'],'plan':p})
    return result

def crowd_widget(data,p=None):
    import streamlit.components.v1 as components
    p=p or plan(data)
    template=Path(__file__).with_name('space_viewer.html').read_text(encoding='utf-8')
    components.html(template.replace('__PAYLOAD__',json.dumps(p,ensure_ascii=False).replace('</','<\\/')),height=875,scrolling=True)

def make_layout_image(data,selected=None,path=None,p=None):
    from geometry import make_layout_image as render
    return render({**data,'_resolved':p or plan(data)},selected,path)
