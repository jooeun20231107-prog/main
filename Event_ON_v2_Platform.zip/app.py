import json, re, sqlite3
from datetime import date,time,datetime,timedelta
import streamlit as st
import storage
from eventon_space import COLORS, STRATEGIES, plan, demand, actual_data, crowd_widget, make_layout_image, optimize_layout_candidates
from report import build_report

st.set_page_config(page_title='Event ON · 행사 자동 설계',page_icon='🎪',layout='wide',initial_sidebar_state='expanded')
st.markdown('''<style>
.stApp{background:#f6f9fd;color:#17233b}[data-testid="stSidebar"]{background:#fff;border-right:1px solid #e2e8f0}.block-container{max-width:1500px;padding-top:2rem}h1{letter-spacing:-.045em;font-size:2.2rem!important}h2,h3{letter-spacing:-.02em}div.stButton>button,div.stDownloadButton>button{border-radius:10px}div[data-testid="stMetric"]{background:white;border:1px solid #e2e8f0;border-radius:14px;padding:15px}div[data-testid="stForm"]{background:white;border-radius:14px}.hero{background:linear-gradient(110deg,#eff6ff,#fff);border:1px solid #dbeafe;border-radius:18px;padding:27px;margin-bottom:20px}.hero small{font-weight:800;letter-spacing:2px;color:#2563eb}.hero h2{margin:10px 0;font-size:29px}.hero p{color:#64748b;line-height:1.7} [data-testid="stTabs"]{margin-top:15px}
</style>''',unsafe_allow_html=True)
DEFAULT={'name':'봄맞이 문화축제','event_type':'축제','purpose':'지역 주민 참여와 문화 체험','visitors':1200,'venue':'야외 축제장','venue_shape':'직사각형 (기본)','site_width':90,'site_depth':60,'event_date':(date.today()+timedelta(days=30)).isoformat(),'duration_days':1,'start_time':'10:00','end_time':'18:00','hours':8,'inside':'실외','mood':'활기찬','age':'전 연령','ticket':'무료','ticket_price':0,'budget':10000000,'facilities':list(COLORS)[:6],'extra':'','layout_positions':{},'strategy':'동선 균형형','clearance':1.5,'corridor_width':3,'peak_fraction':.25,'seed':42}
SHAPES=['직사각형 (기본)','정사각형','원형 광장','돔형 (지붕 있음)','타원형 경기장','L자형']
ENUMS={'event_type':['축제','박람회','공연','체험 행사','컨벤션·강연'],'venue':['야외 축제장','실내 전시장','컨벤션센터','공원·광장','실내 공연장'],'venue_shape':SHAPES,'inside':['실내','실외'],'mood':['활기찬','차분한','감성적인','전문적인','가족 친화적인','미래지향적인'],'age':['전 연령','어린이·가족','청소년','성인','고령층'],'ticket':['무료','유료'],'strategy':list(STRATEGIES)}
@st.cache_data(show_spinner=False,max_entries=32)
def cached_plan(d):return plan(d)
@st.cache_data(show_spinner=False,max_entries=8)
def candidates_for(d):return optimize_layout_candidates(d)

def valid_data(raw):
    if not isinstance(raw,dict):raise ValueError('JSON 최상위는 객체여야 합니다.')
    d={k:raw.get(k,v) for k,v in DEFAULT.items()}
    for k,choices in ENUMS.items():
        if d[k] not in choices:raise ValueError(k+' 선택값을 확인하세요.')
    for k,lo,hi in [('site_width',40,200),('site_depth',35,150),('visitors',1,100000),('duration_days',1,90),('budget',0,100000000000),('ticket_price',0,10000000),('clearance',1,3),('corridor_width',2,6),('peak_fraction',.1,.6),('seed',1,999999)]:
        if not lo<=float(d[k])<=hi:raise ValueError(k+' 범위를 확인하세요.')
        d[k]=int(d[k]) if k in ('visitors','duration_days','budget','ticket_price','seed') else float(d[k])
    if d['clearance'] not in (1.,1.5,2.,2.5,3.) or d['corridor_width'] not in (2.,3.,4.,5.,6.):raise ValueError('통로 폭·여유 간격 선택값을 확인하세요.')
    for k in ('name','purpose','extra'):
        if not isinstance(d[k],str) or len(d[k])>3000:raise ValueError(k+' 텍스트를 확인하세요.')
    if not d['name'].strip():raise ValueError('행사명이 필요합니다.')
    if not isinstance(d['facilities'],list) or not d['facilities'] or any(n not in COLORS for n in d['facilities']):raise ValueError('시설 목록을 확인하세요.')
    date.fromisoformat(d['event_date']);start=time.fromisoformat(d['start_time']);end=time.fromisoformat(d['end_time'])
    sh=start.hour+start.minute/60;eh=end.hour+end.minute/60;d['hours']=eh-sh if eh>sh else eh-sh+24
    if not isinstance(d['layout_positions'],dict):raise ValueError('좌표 객체를 확인하세요.')
    for name,pos in d['layout_positions'].items():
        if name not in COLORS or not isinstance(pos,(tuple,list)) or len(pos)!=2 or not all(0<=float(v)<=1 for v in pos):raise ValueError('시설 상대 좌표는 0~1이어야 합니다.')
    return d

def initialize():
    for key,value in [('user',None),('design',dict(DEFAULT)),('pid',None),('revision',0),('nav','홈')]:
        if key not in st.session_state:st.session_state[key]=value
initialize()
if 'pending_nav' in st.session_state: st.session_state.nav=st.session_state.pop('pending_nav')

def auth():
    st.markdown('<div class="hero"><small>EVENT ON</small><h2>아이디어를 행사 공간으로.</h2><p>행사 정보를 입력하고, 공간을 배치하고, 방문객 흐름을 확인하세요.</p></div>',unsafe_allow_html=True)
    a,b=st.columns(2,gap='large')
    with a:
        st.subheader('로그인')
        with st.form('login'):
            un=st.text_input('아이디',max_chars=40);pw=st.text_input('비밀번호',type='password')
            if st.form_submit_button('로그인',type='primary',use_container_width=True):
                now=datetime.now().timestamp()
                if now<st.session_state.get('locked_until',0):st.error('잠시 후 다시 시도해 주세요.')
                else:
                    user=storage.login(un.strip(),pw)
                    if user:st.session_state.user=user;st.session_state.login_failures=0;st.rerun()
                    else:
                        st.session_state.login_failures=st.session_state.get('login_failures',0)+1
                        if st.session_state.login_failures>=5:st.session_state.locked_until=now+60;st.session_state.login_failures=0
                        st.error('아이디 또는 비밀번호를 확인해 주세요.')
    with b:
        st.subheader('회원가입')
        with st.form('signup'):
            name=st.text_input('이름',max_chars=60);un=st.text_input('사용할 아이디',help='영문·숫자·밑줄 3~40자');pw=st.text_input('비밀번호 (8자 이상)',type='password');pw2=st.text_input('비밀번호 확인',type='password')
            if st.form_submit_button('계정 만들기',use_container_width=True):
                if not name.strip() or not re.fullmatch(r'[A-Za-z0-9_]{3,40}',un) or len(pw)<8 or pw!=pw2:st.error('이름·아이디 형식·비밀번호를 확인해 주세요.')
                else:
                    try:storage.register(un,pw,name.strip());st.success('가입 완료! 왼쪽에서 로그인하세요.')
                    except sqlite3.IntegrityError:st.error('이미 사용 중인 아이디입니다.')
    st.info('개발용 SQLite 버전입니다. Cloud 재배포·재시작 시 계정/프로젝트 파일이 유실될 수 있어 JSON 백업이 필요합니다. 실제 서비스에서는 외부 DB와 운영용 인증을 연결하세요.')
if not st.session_state.user:auth();st.stop()
user=storage.profile(st.session_state.user['username'])
if not user:st.session_state.user=None;st.rerun()
owner=user['username']

def apply(data,save=False,pid='keep'):
    data=valid_data(data);p=cached_plan(data);data=actual_data(data,p)
    st.session_state.design=data;st.session_state.revision+=1;st.session_state.pop('candidates',None);st.session_state.pop('pdf',None)
    if pid!='keep':st.session_state.pid=pid
    if save:st.session_state.pid=storage.save_project(owner,data,st.session_state.pid);st.session_state.flash='배치와 행사 정보를 저장했습니다.'
    st.rerun()

def load(pid):
    d=valid_data(storage.load_project(owner,pid));st.session_state.design=d;st.session_state.pid=pid;st.session_state.revision+=1;st.session_state.pop('candidates',None);st.session_state.pop('pdf',None);st.session_state.pending_nav='행사 설계';st.rerun()

with st.sidebar:
    st.title('🎪 Event ON');st.caption('AI EVENT DESIGN PLATFORM')
    st.radio('메뉴',['홈','행사 설계','보고서','프로젝트','설정'],key='nav')
    st.divider();st.write('**'+user['display_name']+'님**');st.caption(user['company'] or '행사 공간 설계 스튜디오')
    if st.button('새 행사 만들기',use_container_width=True):
        st.session_state.design=dict(DEFAULT);st.session_state.pid=None;st.session_state.revision+=1;st.session_state.pop('candidates',None);st.session_state.pop('pdf',None);st.session_state.pending_nav='행사 설계';st.rerun()
    if st.button('로그아웃',use_container_width=True):
        for key in list(st.session_state.keys()):del st.session_state[key]
        st.rerun()
    st.caption('휴리스틱 자동 설계 · 기획용 시뮬레이션')
if 'flash' in st.session_state:st.success(st.session_state.pop('flash'))
d=st.session_state.design
page=st.session_state.nav
if page=='홈':
    st.markdown('<div class="hero"><small>DESIGN YOUR EVENT</small><h2>행사 기획을 더 똑똑하게, Event ON</h2><p>행사 입력부터 공간 배치, 2D·3D 검토, 방문객 이동 시뮬레이션과 보고서까지.<br>동일한 공간 모델로 설계를 이어갑니다.</p></div>',unsafe_allow_html=True)
    a,b,c=st.columns(3)
    with a:
        with st.container(border=True):st.subheader('01 · 행사 입력');st.write('유형·방문객·시설을 선택하면 통로와 간격을 고려해 자동 배치합니다.')
    with b:
        with st.container(border=True):st.subheader('02 · 공간 검토');st.write('2D 평면도와 3D 조감도에서 같은 배치를 확인합니다.')
    with c:
        with st.container(border=True):st.subheader('03 · 비교 및 저장');st.write('세 배치안의 공간 지표를 비교하고 프로젝트를 이어서 수정합니다.')
    st.subheader('최근 프로젝트')
    for pid,title,updated in storage.list_projects(owner)[:5]:
        a,b=st.columns([5,1]);a.write('**'+title+'** · '+updated)
        if b.button('열기',key=f'home{pid}'):load(pid)
    if not storage.list_projects(owner):st.caption('행사 설계 메뉴에서 첫 프로젝트를 만들어 보세요.')
    st.info('AI는 현재 규칙·기하 제약 기반 설계 엔진으로 구현되어 있습니다. 학습된 수요 예측 모델 또는 실측 디지털 트윈으로 표시하지 않습니다.')

elif page=='행사 설계':
    st.title('행사 설계 스튜디오');st.caption('정보 입력 → 자동 배치 → 공간·방문객 검토 → 배치안 비교 및 저장')
    with st.expander('01 · 행사 기본정보',expanded=st.session_state.pid is None):
        with st.form('event_brief_'+str(st.session_state.revision)):
            a,b,c=st.columns(3)
            def choice(label,key):return st.selectbox(label,ENUMS[key],index=ENUMS[key].index(d[key]))
            with a:
                name=st.text_input('행사명',d['name'],max_chars=120);event_type=choice('행사 유형','event_type')
                purposes=['지역 교류·문화 체험','제품 전시·홍보','공연 관람','교육·체험','네트워킹','지역 주민 참여와 문화 체험']
                if d['purpose'] not in purposes:purposes.append(d['purpose'])
                purpose=st.selectbox('주요 목적',purposes,index=purposes.index(d['purpose']))
                counts=sorted(set([100,300,500,800,1000,1200,1500,2000,3000,5000,10000,30000,50000,100000,int(d['visitors'])]));visitors=st.selectbox('총 예상 방문객',counts,index=counts.index(int(d['visitors'])))
                venue=choice('장소 유형','venue');inside=choice('실내·외','inside')
            with b:
                shape=choice('공간 외곽 형태','venue_shape');w=st.number_input('가로 길이 (m)',40,200,int(d['site_width']),5);h=st.number_input('세로 길이 (m)',35,150,int(d['site_depth']),5)
                event_date=st.date_input('시작일',date.fromisoformat(d['event_date']));days=st.number_input('행사 기간 (일)',1,90,int(d['duration_days']))
                t1,t2=st.columns(2)
                with t1:start=st.time_input('운영 시작',time.fromisoformat(d['start_time']))
                with t2:end=st.time_input('운영 종료',time.fromisoformat(d['end_time']))
            with c:
                mood=choice('원하는 분위기','mood');age=choice('주요 연령대','age');ticket=choice('입장료 유형','ticket');price=st.number_input('입장료 (원, 무료는 0)',0,10000000,int(d['ticket_price']),1000);budget=st.number_input('총 계획 예산 (원)',0,100000000000,int(d['budget']),1000000)
                facilities=st.multiselect('필요한 시설',list(COLORS),default=d['facilities'])
            extra=st.text_area('추가 요청',d['extra'],max_chars=2000,help='보고서에 기록됩니다. 현재 엔진은 자연어 요청을 자동 제약으로 해석하지 않습니다.')
            st.caption('정사각형·원형·돔형은 가로·세로 중 작은 값을 한 변/지름으로 사용합니다. 방문객 수는 시설 크기 가정에 반영되지만 부스 수와 실제 수용 능력을 산정하는 모델은 아닙니다. 종료시간이 시작 이하이면 익일 종료로 계산합니다.')
            if st.form_submit_button('자동 배치 생성 및 프로젝트 저장',type='primary',use_container_width=True):
                if not facilities:st.error('시설을 하나 이상 선택해 주세요.')
                else:
                    updated={**d,'name':name.strip() or '새 행사','event_type':event_type,'purpose':purpose,'visitors':int(visitors),'venue':venue,'venue_shape':shape,'site_width':w,'site_depth':h,'inside':inside,'event_date':event_date.isoformat(),'duration_days':days,'start_time':start.isoformat(timespec='minutes'),'end_time':end.isoformat(timespec='minutes'),'mood':mood,'age':age,'ticket':ticket,'ticket_price':0 if ticket=='무료' else price,'budget':budget,'facilities':facilities,'extra':extra,'layout_positions':{}}
                    with st.spinner('공간 제약과 접근 경로를 계산하고 있습니다…'):apply(updated,save=True)
    p=cached_plan(d);m=p['metrics']
    for warning in p['warnings']:st.warning(warning)
    k1,k2,k3,k4=st.columns(4);k1.metric('배치 시설',f"{len(p['zones'])}/{len(d['facilities'])}");k2.metric('입구 접근 연결',f"{m['connected']}/{m['facilities']}");k3.metric('평균 접근 거리',f"{m['weighted_distance']} m");k4.metric('선택 배치',d['strategy'])
    left,right=st.columns([3.5,1.1],gap='large')
    with left:
        st.subheader('02 · 공간 및 방문객 흐름')
        crowd_widget(d,p)
    with right:
        st.subheader('시설 위치 수정')
        st.caption('적용 시 2D·3D·시뮬레이션을 함께 갱신하고 프로젝트를 저장합니다.')
        if p['zones']:
            zone=st.selectbox('시설',[z['name'] for z in p['zones']]);z=next(z for z in p['zones'] if z['name']==zone)
            with st.form(f'move_{zone}_{st.session_state.revision}'):
                x=st.slider('가로 중심 (%)',5,95,max(5,min(95,round(z['x']/p['width']*100))))
                y=st.slider('세로 중심 (%)',5,95,max(5,min(95,round(z['y']/p['depth']*100))))
                st.caption(f"시설 크기: {z['w']:g} × {z['h']:g} m")
                if st.form_submit_button('이동 적용 및 저장',use_container_width=True):
                    new=actual_data(d,p);new['layout_positions'][zone]=(x/100,y/100);apply(new,save=True)
        st.divider();st.subheader('설계 가정')
        with st.form('assumptions'):
            clearance=st.select_slider('시설 사이 최소 여유 (m)',options=[1.,1.5,2.,2.5,3.],value=float(d['clearance']))
            corridor=st.select_slider('예약 주 통로 폭 (m)',options=[2.,3.,4.,5.,6.],value=float(d['corridor_width']))
            seed=st.number_input('시뮬레이션 시드',1,999999,int(d['seed']))
            if st.form_submit_button('가정 적용 및 재배치',use_container_width=True):apply({**d,'clearance':clearance,'corridor_width':corridor,'seed':seed,'layout_positions':{}},save=True)
        st.caption('여유와 통로 폭은 기획 가정이며 법정 기준을 의미하지 않습니다. 통로가 좁거나 끊기면 경고를 확인하세요.')
        if st.button('현재 설계 저장',use_container_width=True):apply(d,save=True)
        st.download_button('설계 백업 · JSON',json.dumps(actual_data(d,p),ensure_ascii=False,indent=2),file_name='eventon_project.json',mime='application/json',use_container_width=True)
    st.subheader('03 · 배치안 비교')
    st.caption('전략별 목적함수의 가중치가 다릅니다. 아래 지표는 1 m 자유 공간 격자의 경로와 시설 좌표로 계산하며, 실제 군중 이동을 검증한 예측 점수는 아닙니다.')
    if st.button('동선 균형 · 응급 접근 · 혼잡 분산 비교',type='primary'):
        with st.spinner('세 가지 배치안을 계산하고 있습니다…'):st.session_state.candidates=candidates_for(d)
    candidates=st.session_state.get('candidates',[])
    if candidates:
        cols=st.columns(3)
        descriptions={'동선 균형형':('입구 이동 거리와 시설 분산을 함께 고려합니다.','특정 목적 하나에 특화된 배치보다 우선순위가 분산됩니다.'),'응급 접근형':('의료센터의 입구·주 통로 접근을 더 중시합니다.','다른 시설의 이동 거리나 배치 자유도가 불리해질 수 있습니다.'),'혼잡 분산형':('인기 시설을 서로 떨어뜨리는 가중치를 높입니다.','관람객의 전체 이동 거리가 길어질 수 있습니다.')}
        for col,candidate in zip(cols,candidates):
            with col:
                with st.container(border=True):
                    st.subheader(candidate['name']);cm=candidate['metrics'];st.metric('수요 가중 접근 거리',f"{cm['weighted_distance']} m");st.write('의료 평균 접근: '+(f"{cm['medical_distance']} m" if cm['medical_distance'] is not None else '산출 불가'));st.write(f"주요 시설 평균 이격: {cm['busy_separation']} m");st.write(f"경로 중복 비율: {cm['shared_route_pct']}%");st.write(f"배치 {cm['facilities']}/{len(d['facilities'])} · 연결 {cm['connected']}/{cm['facilities']}")
                    st.caption('설계 의도: '+descriptions[candidate['name']][0]);st.caption('검토할 점: '+descriptions[candidate['name']][1])
                    if candidate['warnings']:st.warning('배치/접근 경고가 있습니다. 적용 후 상세 확인이 필요합니다.')
                    if st.button('이 설계 선택 및 저장',key=candidate['name'],use_container_width=True):apply({**d,'strategy':candidate['name'],'layout_positions':candidate['positions']},save=True)
    st.subheader('04 · 시설별 가정 수요 및 공간 분석')
    st.caption('선호 가중치의 합을 100%로 정규화한 값입니다. 실제 방문자 수·방문 확률 예측이 아닙니다.')
    st.dataframe([{'시설':z['name'],'가정 선호 (%)':round(z['share']*100,1),'입구 경로 (m)':z['route_distance'],'크기 (m)':f"{z['w']} × {z['h']}",'접근 연결':'연결' if z['reachable'] else '미연결'} for z in p['zones']],hide_index=True,use_container_width=True)
    with st.expander('지표 계산법과 현재 구현 범위'):
        st.write('평균 접근 거리는 입구에서 각 시설 외부 접근점까지의 최단경로를 시설 선호로 가중 평균한 값입니다. 의료 평균 접근 거리는 각 연결 시설에서 의료센터 외부 접근점까지의 평균 거리입니다. 주요 시설 이격은 공연장·푸드존·체험부스·굿즈 판매 중심 사이의 평균 거리입니다. 경로 중복 비율은 입구 경로 셀 중 선호 합이 0.6을 넘는 셀 비율이며 실제 통로 혼잡도는 아닙니다.')
        st.write('에이전트는 가중 목적지 선택, 경로별 비용 차이, 독립 속도·입장 간격·체류 시간, 근접 반발·감속, 개인 공간 이동 제한, 정체 시 우회 탐색을 사용합니다. 대기는 시설 주변 외부 슬롯에서 이루어지며 완전한 줄서기·서비스 처리 용량 모델은 아닙니다. 의료 접근 경로에는 장시간 체류 목적지를 두지 않지만 다른 방문객의 통과는 허용합니다.')
        st.write('3D는 동일한 공간 구조를 시각화합니다. 실제 센서·지도·BIM과 연결된 운영 디지털 트윈은 아니며 이동 중 실제 행동을 예측하지 않습니다. 시뮬레이션은 화면 설정 변경·Streamlit 재실행 시 초기화됩니다. 프로젝트에는 설계와 시드만 저장합니다.')

elif page=='프로젝트':
    st.title('프로젝트');st.caption('내 행사 정보, 좌표, 선택 배치안, 설계 가정을 저장하고 복원합니다.')
    upload=st.file_uploader('설계 JSON 복원',type=['json'])
    if upload and st.button('새 프로젝트로 복원 및 저장'):
        try:
            if upload.size>1000000:raise ValueError('1 MB 이하의 설계 JSON을 사용하세요.')
            restored=valid_data(json.loads(upload.getvalue()));apply(restored,save=True,pid=None)
        except (ValueError,TypeError,KeyError,OverflowError) as e:st.error('복원 실패: '+str(e))
    projects=storage.list_projects(owner)
    if not projects:st.info('저장한 프로젝트가 없습니다.')
    for pid,title,updated in projects:
        with st.container(border=True):
            a,b,c=st.columns([5,1,1]);a.write('**'+title+'**');a.caption(updated)
            if b.button('불러오기',key=f'load{pid}'):load(pid)
            if c.button('삭제',key=f'del{pid}'):st.session_state.delete_pid=pid
            if st.session_state.get('delete_pid')==pid:
                st.warning('이 프로젝트를 삭제할까요? JSON 백업이 없다면 되돌릴 수 없습니다.')
                yes,no=st.columns(2)
                if yes.button('삭제 확정',key=f'yes{pid}'):
                    storage.delete_project(owner,pid);st.session_state.pop('delete_pid',None)
                    if st.session_state.pid==pid:st.session_state.pid=None
                    st.rerun()
                if no.button('취소',key=f'no{pid}'):st.session_state.pop('delete_pid',None);st.rerun()
    st.warning('Streamlit Cloud의 로컬 SQLite 파일은 영구 저장소가 아닙니다. 운영용 DB로 교체 전에는 JSON 백업을 내려받으세요.')

elif page=='보고서':
    st.title('행사 공간 설계 보고서');p=cached_plan(d);m=p['metrics']
    st.subheader(d['name']);st.caption(f"작성: {user['display_name']} · {user['company'] or '소속 미입력'}")
    st.write(f"{d['event_type']} / {d['purpose']} · 총 예상 방문객 {d['visitors']:,}명")
    st.write(f"{d['event_date']}부터 {d['duration_days']}일 · {d['start_time']}–{d['end_time']} · 예산 {d['budget']:,}원")
    image=make_layout_image(d,p=p).getvalue();st.image(image,use_container_width=True)
    st.write(f"선택 배치: {d['strategy']} · 접근 연결 {m['connected']}/{m['facilities']} · 수요 가중 평균 접근 거리 {m['weighted_distance']} m")
    for warning in p['warnings']:st.warning(warning)
    st.write('추가 요청: '+(d['extra'] or '없음'))
    a,b=st.columns(2)
    a.download_button('설계도 PNG 다운로드',image,file_name='Event_ON_plan.png',mime='image/png',use_container_width=True)
    if b.button('PDF 보고서 생성',type='primary',use_container_width=True):
        with st.spinner('보고서를 생성하고 있습니다…'):st.session_state.pdf=build_report(d,p,user['display_name'],user['company'])
    if st.session_state.get('pdf'):st.download_button('PDF 다운로드',st.session_state.pdf,file_name='Event_ON_report.pdf',mime='application/pdf')
    st.caption('PDF에는 행사 개요·설계도·시설별 좌표·공간 지표·분석 가정이 포함됩니다. 브라우저의 일시적인 군중 이동 통계는 포함하지 않습니다.')

elif page=='설정':
    st.title('설정')
    with st.form('profile'):
        name=st.text_input('이름',user['display_name'],max_chars=60);company=st.text_input('소속·회사',user['company'],max_chars=120)
        if st.form_submit_button('프로필 저장'):
            if name.strip():storage.update_profile(owner,name.strip(),company.strip());st.session_state.pop('pdf',None);st.rerun()
            else:st.error('이름을 입력하세요.')
    with st.form('password'):
        old=st.text_input('현재 비밀번호',type='password');new=st.text_input('새 비밀번호 (8자 이상)',type='password');confirm=st.text_input('새 비밀번호 확인',type='password')
        if st.form_submit_button('비밀번호 변경'):
            if len(new)<8 or new!=confirm:st.error('새 비밀번호를 확인하세요.')
            elif storage.change_password(owner,old,new):st.success('변경했습니다.')
            else:st.error('현재 비밀번호가 일치하지 않습니다.')
    st.info('밝은 화면과 흰색 사이드바를 기본으로 제공합니다. 운영 서비스에는 외부 영구 DB·비밀번호 복구·이메일 검증·서버 측 로그인 시도 제한·운영 보안 검토가 추가로 필요합니다.')
st.divider();st.caption('Event ON · 규칙 기반 자동 설계 및 가상 방문객 시뮬레이션 · 현장 실측과 안전 전문가 검토 필요')
